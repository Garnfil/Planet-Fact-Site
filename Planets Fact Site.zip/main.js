// Click the target planet in navbar
function onPlanet(n) {
  showPlanet(n);
  var homeContainer = document.querySelector
  ('#home-container');
  homeContainer.style.opacity = '0';
}

function showPlanet(n) {
  const planetsContainer = document.querySelectorAll('.planet-content');
 for (var i = 0; i < planetsContainer.length; i++) {
    planetsContainer[i].classList.remove('show');
  }
  
  planetsContainer[planetsContainer.length - n].classList.add('show');
}

function backToHome() {
  window.location.reload();
}